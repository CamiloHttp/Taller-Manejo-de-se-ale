%% Taller: Manejo de señales en herramientas computacionales
% Autor: [Tu nombre]
% Fecha: [Fecha]
% Objetivo: Generación y graficación de señales en MATLAB

%% 2.2 Vector de tiempo
t = 0:0.001:10;  % Tiempo de 0 a 10 s con resolución de 1 ms

%% 2.3 Generación de señales

% 2.3.1 Impulso (en t = 0)
impulso = zeros(size(t));
impulso(t==0) = 1;

% 2.3.2 Escalón
escalon = ones(size(t));

% 2.3.3 Señal sinusoidal (Amplitud 2, Frecuencia 3 Hz)
f = 3;      % frecuencia
A = 2;      % amplitud
sinusoidal = A * sin(2*pi*f*t);

% 2.3.4 Exponencial creciente
exp_creciente = exp(2*t);

% 2.3.5 Exponencial decreciente
exp_decreciente = exp(-4*t);

%% 2.4 Graficar señales
figure;

subplot(3,2,1);
stem(t, impulso, 'r');
title('Impulso');
xlabel('Tiempo (s)');
ylabel('Amplitud');
xlim([-0.01 0.01]);

subplot(3,2,2);
plot(t, escalon, 'b');
title('Escalon');
xlabel('Tiempo (s)');
ylabel('Amplitud');

subplot(3,2,3);
plot(t, sinusoidal, 'm');
title('Señal sinusoidal');
xlabel('Tiempo (s)');
ylabel('Amplitud');

subplot(3,2,4);
plot(t, exp_creciente, 'g');
title('Exponencial creciente');
xlabel('Tiempo (s)');
ylabel('Amplitud');

subplot(3,2,5);
plot(t, exp_decreciente, 'k');
title('Exponencial decreciente');
xlabel('Tiempo (s)');
ylabel('Amplitud');
