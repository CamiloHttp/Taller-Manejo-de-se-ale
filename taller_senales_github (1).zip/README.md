# Taller: Manejo de señales en herramientas computacionales

## 📌 Objetivo
Fortalecer el manejo de herramientas computacionales para el tratamiento de señales digitales.

---

## ✅ 1. Herramientas
Se analizaron las siguientes herramientas de análisis numérico:

### MATLAB
- **Fortalezas:** Especializado en procesamiento de señales, muchas funciones integradas.
- **Debilidades:** Licencia costosa, no es open source.

### Python (NumPy, SciPy, Matplotlib)
- **Fortalezas:** Gratuito, librerías potentes, comunidad activa.
- **Debilidades:** Menor rendimiento en ciertas operaciones, requiere instalación.

### Octave
- **Fortalezas:** Gratuito, sintaxis similar a MATLAB.
- **Debilidades:** Menos funciones avanzadas.

**Herramienta elegida:** MATLAB por su facilidad para trabajar señales y sus funciones integradas.

---

## ✅ 2. Ejercicios
- Vector de tiempo: `t = 0:0.001:10;`
- Señales generadas:
  - Impulso
  - Escalón
  - Sinusoidal (A=2, f=3Hz)
  - Exponencial creciente
  - Exponencial decreciente
- Gráficas organizadas en una sola figura.

📂 El código completo se encuentra en [`taller_senales.m`](./taller_senales.m).

---

## ✅ 3. Preguntas

### 3.1 Frecuencia de muestreo usada
Resolución: `0.001 s` → **Frecuencia de muestreo = 1000 Hz (1 kHz)**.

### 3.2 Memoria necesaria para almacenar las señales
- Número de muestras: `10001`
- Cada muestra: `8 bytes` (double)
- Por señal: ~78.1 kB
- **Total 5 señales:** ~390 kB

---

## ▶ Ejecución
Abrir el archivo `taller_senales.m` en MATLAB y ejecutar para visualizar las gráficas.
